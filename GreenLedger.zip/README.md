# GreenLedger – Transparent Carbon Action Tracker

Tracks community eco-actions, verifies via blockchain, and rewards EcoCredits.

Built with Python (PyTeal), Algorand, React/Tailwind, and Firebase/Supabase.

