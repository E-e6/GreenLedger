# GreenLedger – Transparent Carbon Action Tracker

GreenLedger is a blockchain-powered platform that:

- Tracks community eco-actions (e.g., tree planting, recycling, renewable energy use)
- Verifies contributions through photo/QR evidence (placeholder in demo)
- Rewards users with EcoCredits
- Provides real-time dashboards for schools or communities

## Tech Stack

- Frontend: HTML/CSS (React/Tailwind optional)
- Backend/Demo: Python simulate.py
- Blockchain: Placeholder for Algorand smart contract
- Data: log.json to track points

## How to Demo

1. Open `index.html` in your browser to see the frontend.
2. Run `python simulate.py` to simulate earning EcoCredits.

## What's Next

- Integrate real Algorand smart contracts
- Add Firebase/Supabase backend
- Expand EcoCredit gamification and dashboards
