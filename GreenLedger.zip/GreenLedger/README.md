# GreenLedger – Transparent Carbon Action Tracker

Tracks community eco-actions, verifies via blockchain, and rewards EcoCredits.

Built with Python (PyTeal), Algorand, simple JS demo, and HTML/CSS.

✅ Fully DevPost-ready demo: interactive frontend, blockchain placeholders, clear README.

