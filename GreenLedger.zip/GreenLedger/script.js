console.log("GreenLedger demo frontend loaded");
